<?php $__env->startSection('title','Inicio - '.config('app.name')); ?>
<?php $__env->startSection('header','Inicio'); ?>
<?php $__env->startSection('breadcrumb'); ?>
	<ol class="breadcrumb">
	  <li class="active"><i class="fa fa-home" aria-hidden="true"></i> Inicio</li>
	</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h2>DOCUMENTOS</h2>			
		</div>   
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>