<!DOCTYPE html>
<html>
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminLTE.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/glyphicons.css')); ?>">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(asset('css/_all-skins.min.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>">
  </head>
	<body class="hold-transition login-page">
	  <div class="login-box">
	    <div class="login-logo">
	    <center><img class="img-responsive" src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" style="height:75px"></center>
	      <a href="#"><b><?php echo e(config('app.name')); ?></b></a>
	    </div><!-- /.login-logo -->
	    <div class="login-box-body">
	      <p class="login-box-msg">-Solo  personal autorizado-</p>
	      <?php if(count($errors) > 0): ?>
	        <div class="alert alert-danger">
	        	<ul>
	          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	             <li><?php echo e($error); ?></li>
	          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         	</ul>  
	        </div>
	      <?php endif; ?>
	      <form action="<?php echo e(route('auth')); ?>" method="POST">
	          <?php echo e(csrf_field()); ?>

	        <div class="form-group has-feedback">
	          <input  class="form-control" type="email" name="email" placeholder="Email">
	          <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
	        </div>
	        <div class="form-group has-feedback">
	          <input id="password" class="form-control" type="password" name="password" placeholder="Password">
	          <span class="glyphicon glyphicon-lock form-control-feedback"></span>
	        </div>

	        <div class="form-group">
	            <button id="b-login" type="submit" class="btn btn-primary btn-block btn-flat">Entrar</button>
	        </div>
	      </form> 
	    </div><!-- /.login-box-body -->
	  </div><!-- /.login-box -->
	</body>
</html>
