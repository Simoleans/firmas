<?php $__env->startSection('title','Acta - '.config('app.name')); ?>
<?php $__env->startSection('header','Acta'); ?>
<?php $__env->startSection('breadcrumb'); ?>
	<ol class="breadcrumb">
	  <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home" aria-hidden="true"></i> Inicio</a></li>
	  <li> Acta <?php echo e($acta->codigo); ?> </li>
	  <li class="active">Ver </li>
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<section>
    <a class="btn btn-flat btn-default" href="<?php echo e(route('actas.index')); ?>"><i class="fa fa-reply" aria-hidden="true"></i> Volver</a>
    
    <!-- <button class="btn btn-flat btn-danger" data-toggle="modal" data-target="#delModal"><i class="fa fa-times" aria-hidden="true"></i> Eliminar</button> -->
	</section>

	<section class="perfil">
		<div class="row">
    	<div class="col-md-12">
    		<h2 class="page-header" style="margin-top:0!important">
          <i class="fa fa-user" aria-hidden="true"></i>
          <?php echo e('Acta '.$acta->codigo); ?>

          <small class="pull-right">Registrado: <?php echo e($acta->created_at); ?></small>
          <span class="clearfix"></span>
        </h2>
    	</div>
			<div class="col-md-5">
				<h4>Detalles de la empresa</h4>
				<p><b>Usuario: </b> <?php echo e($acta->user->nombre); ?> </p>
        <p><b>Empresa: </b> <?php echo e(strtoupper($acta->empresa->r_social)); ?></p>
        <p><b>Ciudad: </b> <?php echo e(strtoupper($acta->empresa->ciudad)); ?></p>
        <p><b>RUT: </b> <?php echo e(strtoupper($acta->empresa->rut)); ?></p>
        <p><b>Contacto: </b> <?php echo e(strtoupper($acta->empresa->contacto)); ?></p>
        <p><b>Telefono: </b> <?php echo e(strtoupper($acta->empresa->telefono)); ?></p>
        <p><b>Direccion: </b> <?php echo e(strtoupper($acta->empresa->direccion)); ?></p>
        
			</div>

      <div class="col-md-4"> 
        <p>&nbsp;</p>
        <p><b>Observaciones: </b> <?php echo e($acta->observaciones?$acta->observaciones:'N/T'); ?> </p>
      </div>

      <div class="col-md-2"> 
        <p>&nbsp;</p>
        <p><b>Logo</b></p>
        <img src="<?php echo e(asset('img/empresas/'.$acta->empresa->logo)); ?>" class="img-responsive">
      </div>
		</div>

    <div class="row">
      <div class="col-md-12">
        <h2 class="page-header" style="margin-top:0!important">
          <i class="fa fa-users" aria-hidden="true"></i>
          Participantes
          <span class="clearfix"></span>
        </h2>
      </div>
      <div class="col-md-12">
       <table class="table data-table table-condensed table-hover table-bordered nowrap" style="width:100%"">
         <thead>
           <tr>
            <th class="text-center">Nombre</th>
            <th class="text-center">Apellido</th>
            <th class="text-center">Cargo</th>
            <th class="text-center">URL</th>
          </tr>
         </thead>
         <tbody>
          <?php $__currentLoopData = $acta->participantes($acta->codigo); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
             <td class="text-center"><?php echo e($p->nombre); ?></td>
             <td class="text-center"><?php echo e($p->apellido); ?></td>
             <td class="text-center"><?php echo e($p->cargo); ?></td>
             <td class="text-center">
                <?php if($p->firma == NULL): ?>
                 <a href="<?php echo e(route('actas.firma',[$p->id])); ?>" target="_blank"><?php echo e(route('actas.firma',[$p->id])); ?></a>
                <?php else: ?>
                 <img src="<?php echo e(asset('img/actas').'/'.$p->firma); ?>" class="img-responsive"  align="center">
                <?php endif; ?>
             </td>
           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
       </table>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <h2 class="page-header" style="margin-top:0!important">
          <i class="fa fa-list" aria-hidden="true"></i>
          Acciones
          <span class="clearfix"></span>
        </h2>
      </div>
      <div class="col-md-12">
       <table class="table table-condensed table-hover table-bordered">
         <thead>
           <tr>
            <th class="text-center">#</th>
            <th class="text-center">Accion</th>
          </tr>
         </thead>
         <tbody>
          <?php $__currentLoopData = $acta->acciones($acta->codigo); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
             <td><?php echo e($loop->index+1); ?></td>
             <td class="text-center"><?php echo e($a->accion); ?></td>
           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
       </table>
      </div>
    </div>
	</section>

	<div id="delModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="delModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="delModalLabel">Eliminar Acta</h4>
        </div>
        <div class="modal-body">
          <div class="row">
            <form class="col-md-8 col-md-offset-2" action="<?php echo e(route('actas.destroy',[$acta->id])); ?>" method="POST">
              <?php echo e(method_field( 'DELETE' )); ?>

              <?php echo e(csrf_field()); ?>

              <h4 class="text-center">¿Esta seguro de eliminar esta acta?</h4><br>

              <center>
                <button class="btn btn-flat btn-danger" type="submit">Eliminar</button>
                <button type="button" class="btn btn-flat btn-default" data-dismiss="modal">Cerrar</button>
              </center>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>