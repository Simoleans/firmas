<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title',config('app.name')); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Icon 16x16 -->
    <link rel="icon" type="image/png" sizes="240x240" href="<?php echo e(asset('img/logo.png')); ?>">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/AdminLTE.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/glyphicons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap.css')); ?>">
     <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/fileinput-rtl.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/fileinput.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/sign_src/css/jquery.signaturepad.css')); ?>">


    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/css/inputmask.min.css" rel="stylesheet"/>
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(asset('css/_all-skins.min.css')); ?>">
  	<style type="text/css">
	    .perfil{
			  position: relative;
			  background: #fff;
			  border: 1px solid #f4f4f4;
			  padding: 20px;
			  margin: 10px 25px;
			}


     
      #btnSaveSign {
        color: #fff;
        background: #f99a0b;
        padding: 5px;
        border: none;
        border-radius: 5px;
        font-size: 20px;
        margin-top: 10px;
      }
      #signArea{
        width:304px;
        margin: 50px auto;
      }
      .sign-container {
        width: 60%;
        margin: auto;
      }
      .sign-preview {
        width: 150px;
        height: 50px;
        border: solid 1px #CFCFCF;
        margin: 10px 5px;
      }
      .tag-ingo {
        font-family: cursive;
        font-size: 16px;
        text-align: center;
        font-style: oblique;
      }
    
	  </style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
      <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo e(route('dashboard')); ?>" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini">
          	<b>FR</b>
          </span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>FIRMA</b></span>
        </a>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Navegación</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              <!-- User Account: style can be found in dropdown.less -->
            <?php if(auth()->guard()->check()): ?>
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <span class="hidden-xs"><?php echo e(Auth::user()->email); ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <p>
                      DESCRIPCCION
                      <small>LEYENDA DEL USUARIO ONLINE</small>
                    </p>
                  </li>
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                  	<div class="pull-left">
                  		<a href="<?php echo e(route('perfil')); ?>" class="btn btn-flat btn-default"><i class="fa fa-user-circle" aria-hidden="true"></i> Perfil</a>
                  	</div>
                    
                   	<div class="pull-right">
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-flat btn-default" type="submit"><i class="fa fa-sign-out" aria-hidden="true"></i> Salir</button>
                      </form>
                    </div>
                  </li>
                </ul>
              </li>
            <?php endif; ?>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
    <?php if(auth()->guard()->check()): ?>
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MENÚ</li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-user"></i>
                <span>Usuarios</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-circle-o"></i>Ver usuarios</a></li>
                <li><a href="<?php echo e(route('users.create')); ?>"><i class="fa fa-circle-o"></i>Agregar usuario</a></li>
              </ul>
            </li>

             <li class="treeview">
              <a href="#">
                <i class="fa fa-industry"></i>
                <span>Empresa</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('empresas.create')); ?>"><i class="fa fa-circle-o"></i> Registrar Empresa</a></li>
                <li><a href="<?php echo e(route('empresas.index')); ?>"><i class="fa fa-circle-o"></i> Mis Empresa</a></li>
              </ul>
            </li>

             <li class="treeview">
              <a href="#">
                <i class="fa fa-users"></i>
                <span>Proveedores</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('proveedor.create')); ?>"><i class="fa fa-circle-o"></i> Registrar Proveedor</a></li>
                <li><a href="<?php echo e(route('proveedor.index')); ?>"><i class="fa fa-circle-o"></i> Mis Proveedores</a></li>
              </ul>
            </li>


            <li class="treeview">
              <a href="#">
                <i class="fa fa-print"></i>
                <span>Documentos</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('ordencompra.create')); ?>"><i class="fa fa-circle-o"></i> Orden Compra</a></li>
                <li><a href="<?php echo e(route('ordencompra.index')); ?>"><i class="fa fa-circle-o"></i> Mis Ordenes De Compra</a></li>
              </ul>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-file-o"></i>
                <span>Actas</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('actas.create')); ?>"><i class="fa fa-circle-o"></i>Crear Acta</a></li>
                <li><a href="<?php echo e(route('actas.index')); ?>"><i class="fa fa-circle-o"></i>Ver Actas</a></li>
              </ul>
            </li>

            <li>
              <a href="#">
                <i class="fa fa-plus-square"></i> <span>Ayuda</span>
                <small class="label pull-right bg-red">PDF</small>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-info-circle"></i> <span>Acerca De...</span>
                <small class="label pull-right bg-yellow">IT</small>
              </a>
            </li>       
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>
    <?php endif; ?>

      <!--Contenido-->
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->
        <section class="content-header">
          <h1>
            <?php echo $__env->yieldContent('header'); ?>
          </h1>
          <?php echo $__env->yieldContent('breadcrumb'); ?>
        </section>
        <!-- Main content -->
        <section class="content">
        	<?php echo $__env->yieldContent('content'); ?>
        </section>
      </div><!-- /.content-wrapper -->
      <!--Fin-Contenido-->
      <footer class="main-footer">
        <strong>Copyright &copy; 2016-2017 <a href="#">Desarrollador</a>.</strong> Todos los derechos reservados.
      </footer>
    </div><!-- .wrapper -->
    <!-- jQuery 2.1.4 -->
    <script type="text/javascript" src="<?php echo e(asset('js/jQuery-2.1.4.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.5 -->
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script type="text/javascript" src="<?php echo e(asset('js/app.min.js')); ?>"></script>
    <!-- Data table -->
    <script type="text/javascript" src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/fileinput.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/inputmask/inputmask.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/4.4.7/themes/fa/theme.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/sign_src/js/bezier.js')); ?>"></script>
     <script type="text/javascript" src="<?php echo e(asset('js/sign_src/js/jquery.signaturepad.js')); ?>"></script>
     <script type="text/javascript" src="<?php echo e(asset('js/sign_src/js/json2.min.js')); ?>"></script>
     <script type="text/javascript" src="<?php echo e(asset('js/sign_src/js/numeric-1.2.6.min.js')); ?>"></script>
     <script type='text/javascript' src="https://github.com/niklasvh/html2canvas/releases/download/0.4.1/html2canvas.js"></script>

     
    <script type="text/javascript">  

      $(document).ready(function(){

        $(".rut").inputmask({
            mask: "9[9.999.999]-[9|K|k]",
          });

        $(".tlf").inputmask({
            mask: "[9-9999-9999]",
          });
      	//Eliminar alertas que no contengan la clase alert-important luego de 7seg
      	$('div.alert').not('.alert-important').delay(7000).slideUp(300);

        

      	//activar Datatable
        $('.data-table').DataTable({
          responsive: true,
          language: {
          	url:'<?php echo e(asset("plugins/datatables/spanish.json")); ?>'
          }
        });
      })
    </script>

    <?php echo $__env->yieldContent('script'); ?>
  </body>
</html>