@extends('layouts.app')
@section('title','Inicio - '.config('app.name'))
@section('header','Inicio')
@section('breadcrumb')
	<ol class="breadcrumb">
	  <li class="active"><i class="fa fa-home" aria-hidden="true"></i> Inicio</li>
	</ol>
@endsection

@section('content')
	<div class="row">
		<div class="col-md-12">
			<h2>DOCUMENTOS</h2>			
		</div>   
  </div>
@endsection